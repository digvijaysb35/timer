# My Timer (Android)

A lightweight, AMOLED-black countdown timer built in Java.

## Included
- Countdown with start, pause/resume, reset and editable hours/minutes/seconds.
- Built-in quick presets (1, 5, 10, 15, 30 minutes), plus up to six saved custom presets. Long-press a custom preset to remove it.
- System alarm tone picker and custom audio-file picker; silent mode is available in the system picker.
- Independent 0–100% alarm loudness control (does not change Android media/ringtone sliders on Android 9+).
- Vibration option, persistent foreground notification, and AMOLED black interface.
- MediaSession remote-volume handling: while the timer service is active, Volume Up or Volume Down stops the countdown or silences the alarm, including with the display off on devices that route hardware volume keys to the active media session.

## Build APK using GitHub Actions (Android phone workflow)
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the outer `MyTimer` folder) to the repository root. Keep `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab and run **Build My Timer APK** (or push to `main`).
4. Open the completed workflow run and download the `MyTimer-debug-apk` artifact. Extract `app-debug.apk` and install it on Android.

## Notes about volume keys and Android
Android does not provide a universal public API that guarantees arbitrary apps can capture physical volume keys in every OEM power-saving mode. This app keeps an active remote-volume MediaSession while the foreground timer is running, which is the supported route for receiving volume-key adjustments with the screen off. Some manufacturers may still prioritize system/OEM behavior. Exempt My Timer from aggressive battery optimization if your device suspends foreground media sessions.

Alarm playback is managed by the app, not by the phone's media-volume slider. The app's alarm-volume slider is stored separately. Minimum supported Android version is Android 9 (API 28), where looping playback and per-ringtone software loudness are available.
