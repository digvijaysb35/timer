package com.example.mytimer;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import androidx.core.app.NotificationCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v4.media.VolumeProviderCompat;
import java.util.Locale;

public class TimerService extends Service {
    public static final String BROADCAST="com.example.mytimer.TIMER_UPDATE";
    public static final String START="START", PAUSE="PAUSE", RESUME="RESUME", RESET="RESET", STOP="STOP", VOLUME="VOLUME";
    private static final int NOTIFY_ID=17;
    private Handler handler; private long endAt=0,remaining=0; private boolean running=false,paused=false,ringing=false;
    private Ringtone ringtone; private Vibrator vibrator; private PowerManager.WakeLock wakeLock; private MediaSessionCompat mediaSession; private VolumeProviderCompat remoteVolumeProvider; private int alarmVolume=80;
    private final Runnable tick=new Runnable(){@Override public void run(){if(!running||paused)return;remaining=Math.max(0,endAt-SystemClock.elapsedRealtime());if(remaining<=0){running=false;ringing=true;startAlarm();publish();updateNotification("Time is up — press either volume button to stop");return;}publish();updateNotification("Timer running · "+format(remaining));handler.postDelayed(this,250);}};

    @Override public void onCreate(){super.onCreate();handler=new Handler(Looper.getMainLooper());vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);alarmVolume=getSharedPreferences("timer",MODE_PRIVATE).getInt("volume",80);createChannel();setupMediaSession();}
    private void setupMediaSession(){
        mediaSession=new MediaSessionCompat(this,"MyTimerVolumeKeys");
        mediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS|MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        
        remoteVolumeProvider=new VolumeProviderCompat(VolumeProviderCompat.VOLUME_CONTROL_ABSOLUTE,100,alarmVolume){
            @Override public void onAdjustVolume(int direction){stopFromVolumeKey();}
            @Override public void onSetVolumeTo(int value){stopFromVolumeKey();}
        };
        mediaSession.setPlaybackToRemote(remoteVolumeProvider);
        mediaSession.setPlaybackState(new PlaybackStateCompat.Builder().setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE|PlaybackStateCompat.ACTION_STOP).setState(PlaybackStateCompat.STATE_PLAYING,0,1f).build());
        mediaSession.setActive(true);
    }
    private void stopFromVolumeKey(){if(ringing||running||paused){handler.post(this::stopEverything);}}
    @Override public int onStartCommand(Intent intent,int flags,int startId){String a=intent==null?"":intent.getAction();if(START.equals(a)){getSharedPreferences("timer",MODE_PRIVATE).edit().putBoolean("active",true).apply();long d=intent.getLongExtra("duration",60000);remaining=d;endAt=SystemClock.elapsedRealtime()+d;running=true;paused=false;ringing=false;stopAlarm();startForeground(NOTIFY_ID,notification("Timer running · "+format(remaining)));mediaSession.setPlaybackState(new PlaybackStateCompat.Builder().setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE|PlaybackStateCompat.ACTION_STOP).setState(PlaybackStateCompat.STATE_PLAYING,0,1f).build());mediaSession.setActive(true);handler.removeCallbacks(tick);handler.post(tick);}else if(PAUSE.equals(a)){if(running){remaining=Math.max(0,endAt-SystemClock.elapsedRealtime());running=false;paused=true;handler.removeCallbacks(tick);publish();updateNotification("Timer paused");}}else if(RESUME.equals(a)){if(paused){paused=false;running=true;endAt=SystemClock.elapsedRealtime()+remaining;startForeground(NOTIFY_ID,notification("Timer resumed"));handler.post(tick);}}else if(RESET.equals(a)||STOP.equals(a)){stopEverything();}else if(VOLUME.equals(a)){if(!getSharedPreferences("timer",MODE_PRIVATE).getBoolean("active",false)){stopSelf();return START_NOT_STICKY;}alarmVolume=intent.getIntExtra("volume",alarmVolume);getSharedPreferences("timer",MODE_PRIVATE).edit().putInt("volume",alarmVolume).apply();if(remoteVolumeProvider!=null)remoteVolumeProvider.setCurrentVolume(alarmVolume);if(ringtone!=null)ringtone.setVolume(alarmVolume/100f);}
        return START_STICKY;
    }
    private void startAlarm(){alarmVolume=getSharedPreferences("timer",MODE_PRIVATE).getInt("volume",alarmVolume);getSharedPreferences("timer",MODE_PRIVATE).edit().putBoolean("vibrating",true).apply();if(getSharedPreferences("timer",MODE_PRIVATE).getBoolean("vibrate",true)&&vibrator!=null){if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0,500,300},0));else vibrator.vibrate(new long[]{0,500,300},0);} PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"MyTimer:AlarmWakeLock");wakeLock.acquire(10*60*1000L);
        String uri=getSharedPreferences("timer",MODE_PRIVATE).getString("sound",RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM).toString());if(!uri.equals("silent://")){try{ringtone=RingtoneManager.getRingtone(this,Uri.parse(uri));if(ringtone!=null){if(Build.VERSION.SDK_INT>=28){ringtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());ringtone.setLooping(true);ringtone.setVolume(alarmVolume/100f);}ringtone.play();}}catch(Exception ignored){}}
        startForeground(NOTIFY_ID,notification("TIME IS UP · press volume to silence"));
    }
    private void stopAlarm(){try{if(ringtone!=null){ringtone.stop();ringtone=null;}}catch(Exception ignored){}if(vibrator!=null)vibrator.cancel();if(wakeLock!=null&&wakeLock.isHeld()){wakeLock.release();wakeLock=null;}}
    private void stopEverything(){getSharedPreferences("timer",MODE_PRIVATE).edit().putBoolean("active",false).apply();handler.removeCallbacks(tick);stopAlarm();running=false;paused=false;ringing=false;remaining=0;publish();stopForeground(true);stopSelf();}
    private void publish(){Intent i=new Intent(BROADCAST);i.setPackage(getPackageName());i.putExtra("remaining",remaining);i.putExtra("running",running);i.putExtra("paused",paused);sendBroadcast(i);}
    private String format(long ms){long s=Math.max(0,(ms+999)/1000);return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("timer_running","Timer",NotificationManager.IMPORTANCE_LOW);c.setDescription("Keeps the countdown active");c.setSound(null,null);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new NotificationCompat.Builder(this,"timer_running").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("My Timer").setContentText(text).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).setPriority(NotificationCompat.PRIORITY_LOW).build();}
    private void updateNotification(String s){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFY_ID,notification(s));}
    @Override public void onTaskRemoved(Intent rootIntent){super.onTaskRemoved(rootIntent);}
    @Override public void onDestroy(){handler.removeCallbacks(tick);stopAlarm();getSharedPreferences("timer",MODE_PRIVATE).edit().putBoolean("active",false).apply();if(mediaSession!=null){mediaSession.setActive(false);mediaSession.release();}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
