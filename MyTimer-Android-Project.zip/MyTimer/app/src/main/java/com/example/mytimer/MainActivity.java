package com.example.mytimer;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO=41, PICK_SYSTEM=42, NOTIFY_REQ=90;
    private TextView timeText,statusText,soundText,volumeText;
    private EditText hours,minutes,seconds;
    private SeekBar ringVolume;
    private LinearLayout presetRow;
    private BroadcastReceiver receiver;
    private boolean running=false, paused=false;
    private long remaining=0;
    private final int bg=0xFF000000, panel=0xFF111111, fg=0xFFF4F4F4, muted=0xFF999999, lime=0xFFB7F36B;

    private android.content.SharedPreferences p(){ return getSharedPreferences("timer",MODE_PRIVATE); }

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); getWindow().getDecorView().setSystemUiVisibility(0);
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFY_REQ);
        buildUi();
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){ remaining=i.getLongExtra("remaining",0); running=i.getBooleanExtra("running",false); paused=i.getBooleanExtra("paused",false); updateDisplay(); }};
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,new IntentFilter(TimerService.BROADCAST),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,new IntentFilter(TimerService.BROADCAST));
    }
    @Override protected void onDestroy(){ if(receiver!=null) unregisterReceiver(receiver); super.onDestroy(); }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(18),dp(22),dp(24)); root.setBackgroundColor(bg); scroll.addView(root); setContentView(scroll);
        TextView brand=text("MY TIMER",22,true,fg); root.addView(brand); TextView sub=text("A simple timer that stays with you.",13,false,muted); root.addView(sub,lp(-1,dp(28)));
        timeText=text("00:00:00",54,true,fg); timeText.setGravity(Gravity.CENTER); timeText.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); root.addView(timeText,lp(-1,dp(116)));
        statusText=text("READY",12,true,muted); statusText.setGravity(Gravity.CENTER); root.addView(statusText,lp(-1,dp(26)));
        LinearLayout fields=new LinearLayout(this); fields.setGravity(Gravity.CENTER); fields.setOrientation(LinearLayout.HORIZONTAL);
        hours=numberField("00"); minutes=numberField("05"); seconds=numberField("00"); fields.addView(hours,lp(0,dp(54),1)); fields.addView(text(":",24,true,muted)); fields.addView(minutes,lp(0,dp(54),1)); fields.addView(text(":",24,true,muted)); fields.addView(seconds,lp(0,dp(54),1)); root.addView(fields,lp(-1,dp(66)));
        TextView presetTitle=text("QUICK PRESETS",12,true,muted); presetTitle.setPadding(0,dp(16),0,dp(8)); root.addView(presetTitle);
        presetRow=new LinearLayout(this); presetRow.setOrientation(LinearLayout.HORIZONTAL); presetRow.setGravity(Gravity.CENTER_VERTICAL); HorizontalScrollView presetScroll=new HorizontalScrollView(this); presetScroll.setHorizontalScrollBarEnabled(false); presetScroll.addView(presetRow); root.addView(presetScroll,lp(-1,dp(48))); refreshPresets();
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(0,dp(18),0,dp(12));
        Button start=button("START",lime,0xFF000000); start.setOnClickListener(v->startTimer()); actions.addView(start,new LinearLayout.LayoutParams(0,dp(54),1));
        Button pause=button("PAUSE / RESUME",panel,fg); pause.setOnClickListener(v->send(paused?TimerService.RESUME:TimerService.PAUSE)); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(54),1); ap.leftMargin=dp(8); actions.addView(pause,ap);
        Button reset=button("RESET",panel,fg); reset.setOnClickListener(v->send(TimerService.RESET)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(54),1); rp.leftMargin=dp(8); actions.addView(reset,rp); root.addView(actions);
        addSection(root,"ALARM SOUND");
        LinearLayout soundRow=new LinearLayout(this); soundRow.setGravity(Gravity.CENTER_VERTICAL); soundRow.setBackground(round(panel,16)); soundRow.setPadding(dp(14),dp(8),dp(8),dp(8));
        soundText=text(soundName(),14,true,fg); soundRow.addView(soundText,new LinearLayout.LayoutParams(0,dp(44),1)); Button sys=smallButton("SYSTEM"); sys.setOnClickListener(v->pickSystem()); soundRow.addView(sys); Button custom=smallButton("MY SOUND"); custom.setOnClickListener(v->pickCustom()); soundRow.addView(custom); root.addView(soundRow);
        TextView volLabel=text("RING VOLUME  ·  INDEPENDENT",12,true,muted); volLabel.setPadding(0,dp(18),0,dp(4)); root.addView(volLabel);
        ringVolume=new SeekBar(this); ringVolume.setMax(100); ringVolume.setProgress(p().getInt("volume",80)); ringVolume.setProgressTintList(android.content.res.ColorStateList.valueOf(lime)); ringVolume.setThumbTintList(android.content.res.ColorStateList.valueOf(lime)); root.addView(ringVolume); volumeText=text(ringVolume.getProgress()+"%",12,false,muted); root.addView(volumeText); ringVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int v,boolean u){volumeText.setText(v+"%"); if(u)p().edit().putInt("volume",v).apply();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){if(p().getBoolean("active",false))send(TimerService.VOLUME);}});
        addSection(root,"OPTIONS");
        Switch vibrate=new Switch(this); vibrate.setText("Vibrate when timer ends"); vibrate.setTextColor(fg); vibrate.setChecked(p().getBoolean("vibrate",true)); vibrate.setButtonTintList(android.content.res.ColorStateList.valueOf(lime)); vibrate.setOnCheckedChangeListener((v,c)->p().edit().putBoolean("vibrate",c).apply()); root.addView(vibrate);
        Switch keep=new Switch(this); keep.setText("Keep screen on while app is open"); keep.setTextColor(fg); keep.setChecked(p().getBoolean("keep",false)); keep.setOnCheckedChangeListener((v,c)->{p().edit().putBoolean("keep",c).apply(); getWindow().addFlags(c?WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON:0); if(!c)getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}); root.addView(keep);
        TextView hint=text("Volume Up or Down stops the countdown or silences the alarm — even with the screen off, while My Timer's active timer notification is running.",12,false,muted); hint.setPadding(0,dp(20),0,dp(4)); root.addView(hint);
    }
    private void refreshPresets(){ presetRow.removeAllViews(); int[] defaults={60,300,600,900,1800}; String[] names={"1 MIN","5 MIN","10 MIN","15 MIN","30 MIN"}; for(int i=0;i<defaults.length;i++){ final int sec=defaults[i]; Button b=smallButton(names[i]); b.setOnClickListener(v->setFields(sec)); LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(dp(66),dp(42)); x.rightMargin=dp(5); presetRow.addView(b,x); }
        Button add=smallButton("+"); add.setOnClickListener(v->savePreset()); presetRow.addView(add,new LinearLayout.LayoutParams(dp(42),dp(42)));
        String raw=p().getString("presets",""); if(!raw.isEmpty()) for(String item:raw.split(",")){try{int sec=Integer.parseInt(item); Button b=smallButton(label(sec)); b.setOnClickListener(v->setFields(sec)); b.setOnLongClickListener(v->{removePreset(sec);return true;}); LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(dp(66),dp(42)); x.rightMargin=dp(5); presetRow.addView(b,x);}catch(Exception ignored){}}
    }
    private void removePreset(int sec){String[] a=p().getString("presets","").split(",");java.util.ArrayList<String> keep=new java.util.ArrayList<>();for(String z:a)if(!z.isEmpty()&&!z.equals(String.valueOf(sec)))keep.add(z);p().edit().putString("presets",android.text.TextUtils.join(",",keep)).apply();refreshPresets();toast("Preset removed");}
    private void savePreset(){ long s=readSeconds(); if(s<=0){toast("Set a time first");return;} String raw=p().getString("presets",""); if(raw.split(",").length>=6 && !raw.isEmpty()){toast("You can save up to 6 custom presets");return;} raw=raw.isEmpty()?""+s:raw+","+s; p().edit().putString("presets",raw).apply(); refreshPresets(); toast("Preset saved"); }
    private String label(int s){return s%3600==0?(s/3600)+" HR":(s%60==0?(s/60)+" MIN":s+" SEC");}
    private void setFields(long s){hours.setText(String.format(Locale.US,"%02d",s/3600));minutes.setText(String.format(Locale.US,"%02d",(s%3600)/60));seconds.setText(String.format(Locale.US,"%02d",s%60));}
    private void startTimer(){long s=readSeconds(); if(s<=0){toast("Enter a duration greater than zero");return;} Intent i=new Intent(this,TimerService.class); i.setAction(TimerService.START); i.putExtra("duration",s*1000); ContextCompat.startForegroundService(this,i);}
    private long readSeconds(){try{return Math.min(99*3600L,Long.parseLong(hours.getText().toString())*3600+Long.parseLong(minutes.getText().toString())*60+Long.parseLong(seconds.getText().toString()));}catch(Exception e){return 0;}}
    private void send(String a){Intent i=new Intent(this,TimerService.class);i.setAction(a);if(a.equals(TimerService.VOLUME))i.putExtra("volume",ringVolume.getProgress());startService(i);}
    private void pickSystem(){Intent i=new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_ALARM);i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,"Choose alarm sound");i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,Uri.parse(p().getString("sound",RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM).toString())));startActivityForResult(i,PICK_SYSTEM);}
    private void pickCustom(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");startActivityForResult(i,PICK_AUDIO);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;Uri u;if(req==PICK_SYSTEM){u=(Uri)data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);if(u==null)u=Uri.parse("silent://");p().edit().putString("sound",u.toString()).putBoolean("custom",false).apply();}else if(req==PICK_AUDIO){u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}p().edit().putString("sound",u.toString()).putBoolean("custom",true).apply();}else return;soundText.setText(soundName());}
    private String soundName(){String s=p().getString("sound",RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM).toString());if(s.equals("silent://"))return "Silent";return p().getBoolean("custom",false)?"Custom audio file":"System alarm tone";}
    private void updateDisplay(){timeText.setText(format(remaining));statusText.setText(running?(paused?"PAUSED":"COUNTING DOWN"):"READY");}
    private String format(long ms){long s=Math.max(0,(ms+999)/1000);return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60);}
    private EditText numberField(String val){EditText e=new EditText(this);e.setSingleLine(true);e.setText(val);e.setTextColor(fg);e.setTextSize(22);e.setGravity(Gravity.CENTER);e.setInputType( android.text.InputType.TYPE_CLASS_NUMBER);e.setBackground(round(panel,12));return e;}
    private TextView text(String s,int size,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s,int color,int tc){Button b=buttonBase(s,color,tc);return b;}
    private Button smallButton(String s){Button b=buttonBase(s,panel,fg);b.setTextSize(11);b.setPadding(dp(7),0,dp(7),0);return b;}
    private Button buttonBase(String s,int color,int tc){Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(13);b.setAllCaps(false);b.setBackground(round(color,14));return b;}
    private void addSection(LinearLayout r,String s){TextView t=text(s,12,true,muted);t.setPadding(0,dp(20),0,dp(8));r.addView(t);}
    private android.graphics.drawable.GradientDrawable round(int c,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(c);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams lp(int w,int h,float weight){return new LinearLayout.LayoutParams(w,h,weight);} private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
